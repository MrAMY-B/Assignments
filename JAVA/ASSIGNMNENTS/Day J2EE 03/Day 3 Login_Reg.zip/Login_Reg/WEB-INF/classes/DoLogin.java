import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class DoLogin extends HttpServlet{
	
	private Connection con;
	public void init()
       {
             try
               {
                     Class.forName("com.mysql.cj.jdbc.Driver");
                     String url="jdbc:mysql://localhost:3306/java";
                     con = DriverManager.getConnection("jdbc:mysql://localhost:3306/java","root","amybro");
               }
		catch(Exception ee)
		{
			ee.printStackTrace();
		}
	}

	public void doPost(HttpServletRequest req,HttpServletResponse res){
		
	try{
			res.setContentType("text/html");
			PrintWriter out = res.getWriter();
			String email = req.getParameter("email");
			String pass = req.getParameter("pass");
			

			PreparedStatement ps=con.prepareStatement("select * from register where email=? and pass=?"); 
			
			ps.setString(1,email);
			ps.setString(2,pass);

			ResultSet rs = ps.executeQuery();
			
			if(rs.next()) {
				System.out.println("-------------------Logged In");
				res.sendRedirect("/Login_Reg/admin.html");
			}
			else{
				System.out.println("-------------------Login Failed");
				res.sendRedirect("/Login_Reg/Login.html");
			}
			
			
			
			

					
	}catch(Exception e){e.printStackTrace();}
	}

}