import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class RegisterServ extends HttpServlet{
	
	private Connection con;
	public void init()
       {
             try
               {
                     Class.forName("com.mysql.cj.jdbc.Driver");
                     String url="jdbc:mysql://localhost:3306/java";
                     con = DriverManager.getConnection("jdbc:mysql://localhost:3306/java","root","amybro");
               }
		catch(Exception ee)
		{
			ee.printStackTrace();
		}
	}

	public void doPost(HttpServletRequest req,HttpServletResponse res){
		
	try{
			res.setContentType("text/html");
			PrintWriter out = res.getWriter();
			String email = req.getParameter("email");
			String name = req.getParameter("name");
			String address = req.getParameter("address");
			String pass = req.getParameter("pass");
			

			PreparedStatement ps=con.prepareStatement("insert into register(name,email,address,pass) values(?,?,?,?)"); 
			ps.setString(1,name);
			ps.setString(2,email);
			ps.setString(3,address);
			ps.setString(4,pass);

			int r = ps.executeUpdate();
			
			if(r>0) {
				System.out.println("-------------REGISTER SUCCESS--------------");
			res.sendRedirect("/Login_Reg/Login.html");
			}
			else{	
				System.out.println("-------------Failed--------------");
			res.sendRedirect("/Login_Reg/Register.html");
			}
			
			
			

					
	}catch(Exception e){e.printStackTrace();}
	}

}