import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class MainServ extends HttpServlet{
	

	public void doPost(HttpServletRequest req,HttpServletResponse res){
		
		try{
	System.out.println("----------------------------------------------doPOST MainSERV---------------------------------------");
		res.setContentType("text/html");
		
		String module = req.getParameter("module");
		System.out.println("--------------------------------"+module+"----------------------------------------------");
		if(module.equalsIgnoreCase("java"))
			req.getRequestDispatcher("JavaModuleServ").forward(req,res);

		else if(module.equalsIgnoreCase("C++"))
			req.getRequestDispatcher("CppModuleServ").forward(req,res);
			
		else if(module.equalsIgnoreCase("Oracle"))
			req.getRequestDispatcher("OracleModuleServ").forward(req,res);
			
		}
		catch(Exception e){e.printStackTrace();}
	}
public void doGet(HttpServletRequest req,HttpServletResponse res){
		
		try{
	System.out.println("----------------------------------------------doGET MainSERV---------------------------------------");
		res.setContentType("text/html");
		
		String module = req.getParameter("module");
		if(module.equalsIgnoreCase("java"))
			req.getRequestDispatcher("JavaModuleServ").forward(req,res);
		else if(module.equalsIgnoreCase("c++"))
			req.getRequestDispatcher("CppModuleServ").forward(req,res);
			
		else if(module.equalsIgnoreCase("Oracle"))
			    
			req.getRequestDispatcher("OracleModuleServ").forward(req,res);
			
		}
		catch(Exception e){e.printStackTrace();}
	}

}