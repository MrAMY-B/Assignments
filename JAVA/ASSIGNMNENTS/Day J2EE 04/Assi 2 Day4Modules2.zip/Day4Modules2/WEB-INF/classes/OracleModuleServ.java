import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class OracleModuleServ extends HttpServlet{
	

	public void doPost(HttpServletRequest req,HttpServletResponse res){
		
		try{
		res.setContentType("text/html");
		res.getWriter().print("<h2 style='text-align:center'>In Oracle Module Servlet</h2>");
		res.getWriter().print("<a style='text-align:center' href='/Day4Modules2/index.html'>Home</a>");
		}
		catch(Exception e){e.printStackTrace();}
	}
	
}