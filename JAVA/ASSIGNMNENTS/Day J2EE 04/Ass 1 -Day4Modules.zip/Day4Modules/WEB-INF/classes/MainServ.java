import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class MainServ extends HttpServlet{
	

	public void doPost(HttpServletRequest req,HttpServletResponse res){
		
		try{
		res.setContentType("text/html");
		String module = req.getParameter("module");
		if(module.equalsIgnoreCase("java"))
			res.sendRedirect("JavaModuleServ");
		else if(module.equalsIgnoreCase("c++"))
			res.sendRedirect("CppModuleServ");
		else if(module.equalsIgnoreCase("Oracle"))
			res.sendRedirect("OracleModuleServ");
		}
		catch(Exception e){e.printStackTrace();}
		
		
	}

}