import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class CppModuleServ extends HttpServlet{
	

	public void doGet(HttpServletRequest req,HttpServletResponse res){
		
		try{
		res.setContentType("text/html");
		res.getWriter().print("<h2 style='text-align:center'>In C++ Module Servlet</h2>");
		res.getWriter().print("<a style='text-align:center' href='/Day4Modules/index.html'>Home</a>");
		}
		catch(Exception e){e.printStackTrace();}
		
		
	}
	

}