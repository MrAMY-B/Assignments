import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

public class DispServ extends HttpServlet{
	

	public void doPost(HttpServletRequest req,HttpServletResponse res){

		try{
		res.setContentType("text/html");
		HttpSession session = req.getSession(true);
		ArrayList<String> list = (ArrayList<String>)session.getAttribute("Modules");
		for(String module:list)
		res.getWriter().print("<h1 style='text-align:center;'>"+module+"</h1>");

		res.getWriter().print("<a style='text-align:center' href='/Day4Modules3/index.html'>Home</a>");
		
		}
		catch(Exception e){e.printStackTrace();}
	}
	
}