import java.io.*;
import java.util.List;
import java.util.ArrayList;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class MainServ extends HttpServlet{
	
public void doPost(HttpServletRequest req,HttpServletResponse res){
				
		try{
		res.setContentType("text/html");
		String module[] = req.getParameterValues("module");
		
		List<String> moduleList = new ArrayList<>();
		
		
		for(int i=0;i<module.length;i++)
		{	moduleList.add(module[i]); System.out.println(module[i]);	}	
		
		HttpSession session = req.getSession(true);
		session.setAttribute("Modules",moduleList);
		
		req.getRequestDispatcher("DispServ").forward(req,res);
			
		}
		catch(Exception e){e.printStackTrace();}
		
		
	}

}