package mypojo;
public class PojoClass{
	public int square(int num){ return num*num; }
}