
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import mypojo.PojoClass;

public class PojoServ extends HttpServlet{

	public void doGet(HttpServletRequest req,HttpServletResponse res){
		
		try{

			res.setContentType("text/html");
			PojoClass pojo = new PojoClass();
			int square =pojo.square(req.getParameter("number"));
			System.out.println("-------------"+square+"-------------");
			res.getWriter().print("<h1>Square : "+square+" </h1>");

			
		}catch(Exception e){e.printStackTrace();}
		
	}

}