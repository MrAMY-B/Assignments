package myfilters;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
public class UserFilter implements Filter{

	public void init(FilterConfig conf){}
			
	public void doFilter(ServletRequest req,ServletResponse res,FilterChain chain){
		
		try{
			
		String name=req.getParameter("uname");
			
		FileWriter fw=new FileWriter("E:\\Eclipse Java\\apache-tomcat-9.0.22\\webapps\\FilterApp\\UserData.txt",true);

		fw.write(name+"123, ");
		System.out.println("------------------"+name+"123 Written in File------------------");
		fw.close();

		PrintWriter pw=res.getWriter();
		pw.println("<h4 style='text-align:center;'>Data Stored in file<h4>");	
		
		chain.doFilter(req,res);
			
		}catch(Exception e){e.printStackTrace();}
		
	}
	public void destroy()
	{
	}

}