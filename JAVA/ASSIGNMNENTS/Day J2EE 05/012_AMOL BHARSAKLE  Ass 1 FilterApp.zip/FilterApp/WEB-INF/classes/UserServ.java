
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import myfilters.UserFilter;

public class UserServ extends HttpServlet{

	public void doGet(HttpServletRequest req,HttpServletResponse res){
		
		try{

			res.setContentType("text/html");

			System.out.println("------------- In User Serv -------------");
			res.getWriter().print("<h1 style='text-align:center;'>Square : "+req.getParameter("uname")+" </h1>");
			res.getWriter().print("<h1 style='text-align:center;'><a href='/FilterApp/index.html'> Add another one</a></h1>");

			
		}catch(Exception e){e.printStackTrace();}
		
	}

}